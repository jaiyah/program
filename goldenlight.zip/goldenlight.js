jQuery(document).ready(function($) {
	
	if (session == 'true') {
		// 현재 각성 공적 점수
		var result = $.ajax({
			url : "/event/151223_goldenlight/myPoint",
			async : false
		});
		
		var responseText = $.parseJSON(result.responseText);
		$('.section-dev-02 .count').text(responseText.myCurrentPoint);
		$('.section-dev-01').attr('style', 'display:none');
		$('.section-dev-02').attr('style', '');
	}
	
	// 각성 공적 점수 상세 내역 보기
	$('.btn-layer-01').click(function() {
		if (session == 'false') {
			alert('로그인이 필요합니다.');
			GNBLogin();
		} else {
			var result = $.ajax({
				url : "/event/151223_goldenlight/myPointHistory",
				async : false,
				dataType : "text"
			});
			
			$('.dialog-content').html(result.responseText);
		}
	})
	
	// 각성 공적 점수 보상 교환
	$('.btn-link-01, .btn-link-02').click(function() {
		if (session == 'false') {
			alert('로그인이 필요합니다.');
			GNBLogin();
		} else {
			var dataObject = {};
			dataObject.couponType = $(this).attr('couponId');
			dataObject.type = 'check';
			var result = $.ajax({
				url : '/event/151223_goldenlight/exchangeReward',
				type: 'POST',
				async : false,
				data : dataObject
			});
			
			var responseText = $.parseJSON(result.responseText);
			var resultCode = responseText.resultCode;

			if (resultCode == 'READY') {
				if (confirm(responseText.rewardItem.exchangePoint + '점으로 ' + responseText.rewardItem.couponName + ' 아이템을 구매하시겠습니까?')) {
					dataObject.type = 'exchange';
					var exchangeResult = $.ajax({
						url : '/event/151223_goldenlight/exchangeReward',
						type: 'POST',
						async : false,
						data : dataObject
					});
					
					var exchanteResponseText = $.parseJSON(exchangeResult.responseText);
					if (exchanteResponseText.resultCode == 'SUCCESS') {
						$('.section-dev-02 .count').text(exchanteResponseText.currentPoint);
						alert('교환이 완료되었습니다. 쿠폰함을 확인해주세요.');
						return;
					} 
				}
			} else if (resultCode == 'NOT_LOGIN') {
				alert('로그인이 필요합니다.');
				GNBLogin();
			} else if (resultCode == 'BLOCK_ACCOUNT') {
				alert('제재 계정은 참여할 수 없습니다.');
				return;
			} else if (resultCode == 'NONE_CHARACTER') {
				alert('이벤트 참여 및 게임 플레이를 하기 위해서 실명 인증이 필요합니다.');
				location.href = $('#realnameCertUrl').val();					
			} else if (resultCode == 'NOT_CONDITION') {
				alert('각성 공적 점수가 부족합니다.');
				return;
			} else if (resultCode == 'NOT_LIMIT_COUPON') {
				alert('[모션 카드] 풍운의 마스터는 계정당 1회만 교환 가능한 아이템입니다.');
				return;
			} else if (resultCode == 'END') {
				alert('프로모션이 종료되었습니다.');
				return;
			} else {
				alert('code : [' + resultCode + '] 유효하지 않은 접근입니다. 관리자에게 문의하세요.' );
				return;
			}
		}
	});
	
});