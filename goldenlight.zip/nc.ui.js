(function (global, $) {

    var $menu = $('.floating-menu li.m'),
        $contents = $('.scroll');

    $(function () {

        $menu.on('click','a', function(e){
            var $target = $(this).parent(),
                idx     = $target.index(),
                section = $contents.eq(idx),
                offsetTop = section.offset().top;

            var $doc = $('html, body');
            $doc.stop()
                .animate({
                    scrollTop :offsetTop
                }, 800);
            return false;
        });
    });

    $(window).scroll(function(){

        var scltop = $(window).scrollTop();

        $.each($contents, function(idx, item){
            var $target = $contents.eq(idx),
                i       = $target.index(),
                targetTop = $target.offset().top;

            if (targetTop <= scltop) {
                $menu.removeClass('on');
                $menu.eq(idx).addClass('on');
            }
            if (!(400 <= scltop)) {
                $menu.removeClass('on');
            }
        })

    });

    var btnTop = $('.btn-top');
    btnTop.on('click','a', function(e){
        e.preventDefault();
        $('html, body').stop()
            .animate({
                scrollTop : 0
            },800)
    })

    /**
     * tooltip layer
     */

    var tooltip = {
        'init' : function() {
            this.btn_tooltip = $('.btn-layer-02');
            this.tooltipClose = $('.tooltip_close');
            this.tooltip = $('.tooltip');
            this.initEvent();
        },
        'initEvent' : function () {
            var _self = this;
            this.btn_tooltip.on('click', function () {
                _self.tooltipShow();
                return false;
            });

            this.tooltipClose.on('click', function () {
                _self.tooltipHide();
                return false;
            })
        },
        'tooltipShow' : function() {
            this.tooltip.show();
        },
        'tooltipHide' : function() {
            this.tooltip.hide();
        }
    };
    tooltip.init();

}(window, window.jQuery));


/**
 * ----------------------------
 * UI : tab
 * ----------------------------
 */
!!function(global, $){

    function Tab() {
        this.$tab   = $('.tab');
        this.$tabLis = this.$tab.children();
        this.$panel = $('.tab-panel');
        this.clickEvent();
    }

    Tab.prototype = {

        'trigger' : function (idx) {
            this.$tabLis.eq(idx).trigger('click');
        }

        ,'clickEvent' : function() {
            var _self = this;
            this.$tab.on('click', 'li', function(e){
                e.preventDefault();
                var panelIndex = $(this).index();
                _self.panelShow(panelIndex);
            });
        }

        ,'panelShow' : function(idx) {
            this.$panel.hide();
            this.$panel.eq(idx).show();
            this.classToggle(idx);
        }

        ,'classToggle' : function (classIdx) {
            if(this.$selectItem != null) {
                this.$selectItem.removeClass('on');
            }
            this.$selectItem = this.$tabLis.eq(classIdx);
            this.$selectItem.addClass('on');
        }

    };

    var tabUI =  new Tab();
    tabUI.trigger(0);
}(window, window.jQuery);