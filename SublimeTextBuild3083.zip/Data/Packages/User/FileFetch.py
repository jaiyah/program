# -*- coding: cp949 -*-

import sublime, sublime_plugin, subprocess, functools

file_list = []
class FileFetchCopyCommand(sublime_plugin.TextCommand):
	def run(self, edit, url):
		global file_list
		add_file = open(url, "r", encoding="utf-8")
		while True: 
			line = add_file.readline()
			if not line: break 
			self.view.insert(edit, 0, line)
		add_file.close()
		file_list = []

class FileFetch(sublime_plugin.TextCommand):
	edit = None
	def run(self, edit):
		global file_list
		global_settings = sublime.load_settings(self.__class__.__name__+'.sublime-settings')
		item = global_settings.get('files', True)
		for name, path in item.items():
			file_list.append([name, path])
		self.view.window().show_quick_panel(file_list, functools.partial(self.on_confirm, file_list))

	def on_confirm(self, paths, result):
		global file_list
		if (result > -1):
			new_file = self.view.window().new_file()
			new_file.run_command('file_fetch_copy', {'url': paths[result][1]})
			file_list = []
		else :
			file_list = []
